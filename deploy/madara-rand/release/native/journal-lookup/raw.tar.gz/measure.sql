DO $$ DECLARE started timestamptz; elapsed double precision; i integer; full_times double precision[] = '{}'; indexed_times double precision[] = '{}'; BEGIN
FOR i IN 1..110 LOOP
started=clock_timestamp(); PERFORM * FROM randomness.records(1) WHERE action=decode('07e5b092fa399d2e510c5f6492d2669c47f0698c4824d3a295cf2a166c25f284','hex'); elapsed=extract(epoch from clock_timestamp()-started)*1000;
IF i>10 THEN full_times=array_append(full_times,elapsed); END IF;
started=clock_timestamp(); PERFORM * FROM randomness.records(1,decode('07e5b092fa399d2e510c5f6492d2669c47f0698c4824d3a295cf2a166c25f284','hex')); elapsed=extract(epoch from clock_timestamp()-started)*1000;
IF i>10 THEN indexed_times=array_append(indexed_times,elapsed); END IF;
END LOOP; RAISE NOTICE '%',json_build_object('history_filter',full_times,'indexed_action',indexed_times); END $$;
