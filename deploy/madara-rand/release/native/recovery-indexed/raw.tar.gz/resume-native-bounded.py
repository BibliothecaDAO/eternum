from pathlib import Path
import sys,json
root=Path('/home/djizus/projects/eternum-randomness');deployment=root/'deploy/madara-rand'
sys.path.insert(0,str(deployment))
from runtime import compose,run
release=Path('/tmp/madara-rand-release-bounded');fixture=Path('/tmp/madara-rand-native-5');out=Path('/tmp/madara-rand-native-recovery-bounded');herald=out/'herald'
env=herald/'herald.env'; env.write_text('\n'.join(line.rsplit('/',1)[0]+'/randomness_replay_5_bounded' if line.startswith('HERALD_REPLAY_DATABASE_URL=') else line for line in env.read_text().splitlines())+'\n')
command=compose(deployment,release,fixture/'service.env')+['-f',str(deployment/'herald.yml'),'--env-file',str(env)]
run([*command,'--profile','replay','config','--format','json'],herald/'compose.json',root)
steps=[('replay-resumed',['python3',str(deployment/'drills/herald-replay.py'),str(release),str(fixture),str(herald),str(out/'replay-resumed')]),('restore',['python3',str(deployment/'drills/restore.py'),str(fixture),str(out/'restore')]),('missing-journal',['python3',str(deployment/'drills/missing-journal.py'),str(release),str(fixture),str(out/'missing-journal')])]
(out/'resume-commands.json').write_text(json.dumps(steps,indent=2)+'\n')
for name,command in steps:
 run(command,out/f'{name}.log',root)
 print(json.dumps({'step':name,'passed':True}),flush=True)
