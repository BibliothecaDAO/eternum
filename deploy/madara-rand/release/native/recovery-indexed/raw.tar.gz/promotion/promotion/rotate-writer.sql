BEGIN;
        DO $$ BEGIN IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname='randomness_writer_3') THEN
          CREATE ROLE randomness_writer_3 LOGIN PASSWORD 'local-rehearsal'; END IF; END $$;
        GRANT USAGE ON SCHEMA randomness TO randomness_writer_3;
        GRANT EXECUTE ON ALL FUNCTIONS IN SCHEMA randomness TO randomness_writer_3;
        UPDATE randomness.stream SET epoch=3,writer='randomness_writer_3' WHERE epoch=2;
        REVOKE ALL ON SCHEMA randomness FROM randomness_writer_2;
        REVOKE ALL ON ALL FUNCTIONS IN SCHEMA randomness FROM randomness_writer_2;
        COMMIT;
