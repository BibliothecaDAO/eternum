from pathlib import Path
import sys,subprocess,json,hashlib
root=Path('/home/djizus/projects/eternum-randomness'); deployment=root/'deploy/madara-rand'
sys.path.insert(0,str(deployment))
from runtime import compose,read_release,run,primary_service
release=Path('/tmp/madara-rand-release-bounded');fixture=Path('/tmp/madara-rand-native-5');out=Path('/tmp/madara-rand-native-recovery-bounded')
out.mkdir(exist_ok=False)
commands=[]
def step(name,command,input_text=None):
 commands.append({'step':name,'command':command})
 (out/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
 run(command,out/f'{name}.log',root,input_text)
 print(json.dumps({'step':name,'passed':True}),flush=True)
sql=['docker','exec','-i','madara-rand-journal-replacement-1','psql','-U','postgres','-d','randomness_execution_5','-v','ON_ERROR_STOP=1']
audit="SELECT json_build_object('head',(SELECT row_to_json(s) FROM randomness.stream s),'rows',count(*),'integrity',encode(sha256(decode(string_agg(encode(integrity,'hex'),'' ORDER BY ticket_order),'hex')),'hex')) FROM randomness.tickets"
step('before-lookup-update',[*sql,'-Atc',audit])
lookup=Path('/home/djizus/projects/madara/madara/crates/client/sequencer-randomness/src/journal-lookup.sql')
step('apply-lookup-update',[*sql,'--single-transaction','-f','-'],lookup.read_text())
step('after-lookup-update',[*sql,'-Atc',audit])
assert json.loads((out/'before-lookup-update.log').read_text())==json.loads((out/'after-lookup-update.log').read_text())
step('placements',['python3',str(deployment/'deployed-check.py'),str(release),str(fixture),str(out/'placements')])
# Preserve the prior confirmed reconstruction and create an empty, separately named read store.
command=compose(deployment,release,fixture/'service.env')
herald=out/'herald';herald.mkdir()
old=Path('/tmp/madara-rand-native-herald-live-5/herald.env').read_text()
(herald/'herald.env').write_text(old.replace('randomness_replay_5','randomness_replay_5_bounded'))
step('new-replay-database',[*command,'exec','-T',primary_service(command),'psql','-U','postgres','-d','postgres','-v','ON_ERROR_STOP=1','-c','CREATE DATABASE randomness_replay_5_bounded'])
def readers(name):
 command=compose(deployment,release,fixture/'service.env')+['-f',str(deployment/'herald.yml'),'--env-file',str(herald/'herald.env')]
 with (herald/'compose.json').open('w') as file:subprocess.run([*command,'--profile','replay','config','--format','json'],stdout=file,check=True)
 step(name,[*command,'up','-d','--wait','herald'])
readers('native-reader')
for mode in ('before-broadcast','after-broadcast'):
 step(mode,['python3',str(deployment/'drills/submission-crash.py'),str(release),str(fixture),mode,str(out/mode)])
step('nonce-races',['bun',str(deployment/'race-native-intents.ts'),str(fixture/'fixture.json'),str(out/'nonce-races.json')])
step('promotion',['python3',str(deployment/'drills/submission-crash.py'),str(release),str(fixture),'promote-before-broadcast',str(out/'promotion')])
(herald/'herald.env').write_text((herald/'herald.env').read_text().replace('@journal-replacement:', '@journal-successor:'))
readers('resume-native-reader')
step('partition',['python3',str(deployment/'drills/preview-partition.py'),str(release),str(fixture),str(out/'partition')])
step('replay',['python3',str(deployment/'drills/herald-replay.py'),str(release),str(fixture),str(herald),str(out/'replay')])
step('restore',['python3',str(deployment/'drills/restore.py'),str(fixture),str(out/'restore')])
step('missing-journal',['python3',str(deployment/'drills/missing-journal.py'),str(release),str(fixture),str(out/'missing-journal')])
print(json.dumps({'scope':'single-host real-domain recovery gates','passed':True,'release':read_release(release)['image']}),flush=True)
