import sys,json,urllib.request
from pathlib import Path
r=Path('/home/djizus/projects/eternum-randomness');d=r/'deploy/madara-rand';sys.path[:0]=[str(d),str(d/'drills')]
import promote
from runtime import compose,run,read_fixture
release=Path('/tmp/madara-rand-release-measurement');fixture=Path('/tmp/madara-rand-native-5');out=Path('/tmp/madara-rand-native-promotion-5');p=out/'promotion';f=read_fixture(fixture);c=compose(d,release,fixture/'service.env')+['-f',str(d/'drills/promotion-next.yml')]
promote.rotate_writer(c,d,f,p)
run(['bun','deploy/madara-rand/rotate-fixture.ts',str(fixture/'fixture.json'),str(p/'authority.json')],p/'rotate-authority.log',r)
promote.resume_configuration(fixture)
run([*c,'up','-d','--wait','--no-deps','madara'],p/'node-new-authority.log',d)
q=urllib.request.Request('http://127.0.0.1:15050',data=(out/'submitted-transaction.json').read_bytes(),headers={'content-type':'application/json'})
v=json.load(urllib.request.urlopen(q,timeout=10));(p/'stale-submission.json').write_text(json.dumps(v,indent=2)+'\n');assert 'authority' in json.dumps(v.get('error','')).lower(),v
run([*c,'--profile','sidecar','up','-d','--no-deps','randomness-sidecar'],out/'recover.log',d)
import importlib.util
spec=importlib.util.spec_from_file_location('crash',d/'drills/submission-crash.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
m.verify_recovered_action(c,d,'randomness_execution_5',f,json.loads((out/'before.json').read_text()),json.loads((out/'pending.json').read_text()),out)
from drill_runtime import write_drill_report
write_drill_report(out,{'scope':'single-host native gameplay recovery; not host-loss evidence','mode':'promote-before-broadcast','passed':True,'original_binding_consumed':True,'manual_continuation':'Replacement base backup waited for a spread checkpoint; an explicit CHECKPOINT completed it. Bootstrap now requests a fast checkpoint. The original failure logs are retained.'})
